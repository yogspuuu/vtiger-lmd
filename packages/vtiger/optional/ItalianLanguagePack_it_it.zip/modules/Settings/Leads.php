<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'LBL_CONVERT_LEAD_FIELD_MAPPING' => 'Converti Mappatura Lead'      , // TODO: Review
	'LBL_ORGANIZATIONS'            => 'Aziende'               , // TODO: Review
	'LBL_CONTACTS'                 => 'Contatti'                    , // TODO: Review
	'LBL_OPPURTUNITIES'            => 'Opportunità'               , // TODO: Review
);
$jsLanguageStrings = array(
);